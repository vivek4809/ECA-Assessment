package com.sapient.eca.ProductService.services;


import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sapient.eca.ProductService.entity.Product;
import com.sapient.eca.ProductService.exception.ProductServiceCustomException;
import com.sapient.eca.ProductService.model.ProductRequest;
import com.sapient.eca.ProductService.model.ProductResponse;
import com.sapient.eca.ProductService.repository.ProductRepository;


@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public long addProduct(ProductRequest productRequest) {
        System.out.println("Adding product...");
        Product product = new Product(productRequest.getName(),productRequest.getPrice(),productRequest.getQuantity());
        productRepository.save(product);

        System.out.println("Product with id "+ product.getProductId()+"  created.");
        return product.getProductId();
    }

    @Override
    public ProductResponse getProductById(long productId) {
        System.out.println("Get the product for product id: " + productId);
        Product product = productRepository.findById(productId).orElseThrow(
                () -> new ProductServiceCustomException("Product with id: " +
                        productId + " is not exists.", "PRODUCT_NOT_FOUND"));

        ProductResponse productResponse = new ProductResponse();
        BeanUtils.copyProperties(product, productResponse);

        return productResponse;
    }

    @Override
    public void reduceQuantity(long productId, long quantity) {
        System.out.println("Reduce quantity "+ quantity +" for Id " + productId);

        Product product = productRepository.findById(productId).orElseThrow(
                () -> new ProductServiceCustomException(
                        "No product with id " + productId + " was found!",
                        "NOT_FOUND"));
        if (product.getQuantity() < quantity) {
            throw new ProductServiceCustomException(
                    "Product does not have sufficient quantity",
                    "INSUFFICIENT_QUANTITY");
        }

        product.setQuantity(product.getQuantity() - quantity);
        productRepository.save(product);

        System.out.println("Product quantity updated successfully");
    }
}
