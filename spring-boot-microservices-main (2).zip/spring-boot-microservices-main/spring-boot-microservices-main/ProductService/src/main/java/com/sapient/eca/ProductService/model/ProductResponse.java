package com.sapient.eca.ProductService.model;


public class ProductResponse {
    private long productId;
    private String productName;
    private long quantity;
    private long price;
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	public ProductResponse(long productId, String productName, long quantity, long price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.quantity = quantity;
		this.price = price;
	}
	public ProductResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}
