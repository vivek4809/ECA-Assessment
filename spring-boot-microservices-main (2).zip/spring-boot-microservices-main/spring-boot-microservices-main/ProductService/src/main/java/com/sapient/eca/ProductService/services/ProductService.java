package com.sapient.eca.ProductService.services;

import com.sapient.eca.ProductService.model.ProductRequest;
import com.sapient.eca.ProductService.model.ProductResponse;

public interface ProductService {
    long addProduct(ProductRequest productRequest);

    ProductResponse getProductById(long productId);

    void reduceQuantity(long productId, long quantity);
}
